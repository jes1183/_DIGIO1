SWITCH NI

02/02/17: Nate Gove
TE00591110.07 Updates:
> Incorporated Wrapper Library TE00593720.22
> Added a case statement around the Set command to pass through variables if no parameters or values are sent to the set command.

01/30/17: Nate Gove
TE00591110.06 Updates:
> Incorporated Wrapper Library TE00593720.21
> Moved Wrapper.HWID into Initialize so it is only updated from the instrument during initialization.

01/29/17: Nate Gove
TE00591110.05 Updates:
> Incorporated Wrapper Library TE00593720.20, or SyntaxID=04

01/12/17: Nate Gove
TE00591110.02 Updates:
> Updated TE00591110.00 to SyntaxID=03 of the Wrapper Library TE00593720.11
> Added "Add Resource Name to Channel" boolean button which added text within the Channel combo-box, this feature is useful when one resource has multiple resource types. This is defaulted to ON.
