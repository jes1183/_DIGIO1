DCSOURCE Xantrex

01/24/17:
TE00595600.52
> Dropped in TE00593720.19 and rebuilt. This library update included fixes for logging related functions.

TE00595600.51
> Updated structure to include default "Send Only Updates", which is set to False by default. This will send any command received to the resource.

TE00595600.50 
> This version is identical to TE00595620.10. These previous versions did not follow the configuration management guidelines and are being reset to the correct version here.

TE00595620.10 Updates
> Modified structure of Set command and many other sections to improve design.

01/20/17: Nate Gove:
TE00595620.08 Updates:
> Implemented TE00593720.14 which includes updated ShowHideDisplay.vi

01/03/17: Nate Gove
TE00595620.07 Updates:
> Added Voltage.Gain functionality
> Implemented TE00593720.09 Library

12/20/16: Nate Gove
TE00595620.06 Changes:
> Updated to SyntaxID=03 or Version 3 of (unreleased version is TE00593720.08) Wrapper Library
>> Created sub-vi's for standard code and moved that code to the wrapper library
>> Updated error handling
>> Added Logging Timeout functionality
>> Improved InitializeDefaults.vi sub-vi

10/20/16: Nate Gove

TE00595620.01 Changes: 
> Routed LoggingClass to command producer loop so error file can be written to by SocketReceive.vi
> Routed main variant dictionary to command producer loop and shift register the variant dictionary
> Added standard error handling technique to EnQueue within command producer loop
> Modified LogEntryEnQueue.vi to pass out the error, this is necessary because SocketRead.vi requires the previous error from this loop
 
> TE00593711.12 Changes: TCP Socket Error Updates
>> Updated all other VIs in the LoggingClass folder  to use the same error handling technique, which is to pass the first error along while allowing the vi to execute.
>>> If the input error or first error is not passed through then terminal is label "Error Reset OUT"
>> SocketReceive.vi Changes:
>>> Modified to properly close on repetitive TCP Socket Errors. If TeamMate crashes, TCP Read.vi will output Error 66 continuously.
>>> Reads wrapper timeout from *.atx config file or defaults to 15 second wrapper timeout if value is not found in configuration file
>>> Added 100 msec wait to prevent unnecessary consumption of CPU
>>> Write all unique errors to *.err error file
>>> A negative or no error condition before the timeout expires will restart the timeout timer
>> ParseConfig.vi Changes:
>>>	Modified to read "Timeout" or wrapper timeout from *.atx file 